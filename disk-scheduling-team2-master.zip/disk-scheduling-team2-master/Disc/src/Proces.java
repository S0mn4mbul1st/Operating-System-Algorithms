
public class Proces {
public int position;
public int dedline;
public boolean isAccesed;
public Proces(int pos, int dl) {
	position=pos;
	dedline=dl;
	isAccesed=false;
}
public void reset() {
	isAccesed=false;
}
public void acces() {
	isAccesed=true;
}
}
