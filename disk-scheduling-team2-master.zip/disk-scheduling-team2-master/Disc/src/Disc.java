import java.util.*;
public class Disc {
	public static int distance;
	public int headPosition;
	public int totalMovement=0;
	public int actualPosition;
	public int totalAmountOfCylinders;
	public int path=0;
	public boolean accessed=false;
public Disc() {}
	public Disc(int head, int cylinders) {
		headPosition=head;
		actualPosition=head;
		totalAmountOfCylinders=cylinders;
	}
	public void go(int nextPosition) {
		path=Math.abs(nextPosition-actualPosition);
		totalMovement+=path;
		actualPosition=nextPosition;
	}
	public void reset() {
		actualPosition=headPosition;
		totalMovement=0;
	}
	public int posDiff(int pos) {
		if (pos > totalAmountOfCylinders || pos < 0) {
            throw new IndexOutOfBoundsException(); 
        }
        return Math.abs(actualPosition - pos);	
	
	}
	public  int getDistance() {
		return distance;
	}
	public static void setDistance(int distance) {
		Disc.distance = distance;
	}
	
}
