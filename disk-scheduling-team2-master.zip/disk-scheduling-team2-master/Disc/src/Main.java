import java.util.*;
public class Main {
public static void SCAN(Disc disc, ArrayList<Proces> input) {
	int[] positionsTemp=new int[input.size()];
	for(int i=0;i<positionsTemp.length;i++) {
		positionsTemp[i]=input.get(i).position;
	}
	Arrays.sort(positionsTemp);
	int[] positions2=new int[positionsTemp.length];
	int j=0;
	int firstExecuted=0;
	for(int i=positionsTemp.length-1;i>=0;i--) {
		if(positionsTemp[i]<disc.headPosition) {
			positions2[j]=positionsTemp[i];
			j++;
		}
	}
	for(int i=0;i<positionsTemp.length;i++) {
		if(positionsTemp[i]<disc.headPosition) {
			firstExecuted=positionsTemp[i];
		}
	}
	for(int i=0;i<positionsTemp.length;i++) {
		if(positionsTemp[i]>firstExecuted) {
			positions2[j]=positionsTemp[i];
			j++;
		}
	}
	for(int i=0;i<positions2.length;i++) {
		disc.go(positions2[i]);
	}
	System.out.println("\nScan: "+disc.totalMovement);
	System.out.print("Queue of execution: \n");
    for(int p:positions2)System.out.print(p+ " ");
   
	
}
public static void CSCAN(Disc disc, ArrayList<Proces> input) {
	int[] positionsTemp=new int[input.size()];
	for(int i=0;i<positionsTemp.length;i++) {
		positionsTemp[i]=input.get(i).position;
	}
	Arrays.sort(positionsTemp);
	int[] positions2=new int[positionsTemp.length];
	int j=0;
	for(int i=0;i<positionsTemp.length;i++) {
		if(positionsTemp[i]>disc.headPosition) {
			positions2[j]=positionsTemp[i];
			j++;
		}
	}
	for(int i=0;i<positionsTemp.length;i++) {
		if(positionsTemp[i]<disc.headPosition) {
			positions2[j]=positionsTemp[i];
			j++;
		}
	}
	for(int i=0;i<positions2.length;i++) {
		if(i!=0) {
		if(positions2[i]>positions2[i-1]) disc.go(positions2[i]);
		else {
			disc.path=(disc.totalAmountOfCylinders-disc.actualPosition)+positions2[i];
			disc.totalMovement+=disc.path;
			disc.actualPosition=positions2[i];
		}
		}
		disc.go(positions2[i]);
	}
	System.out.println("\nC-Scan: "+disc.totalMovement);
	System.out.print("Queue of execution: \n");
    for(int p:positions2)System.out.print(p+ " ");
}
public static void FCFS(Disc disc, ArrayList<Proces> input) {
	    int [] positions2=new int [input.size()];
	    for(int i=0;i<positions2.length;i++) {
	    	positions2[i]=input.get(i).position;
	    }
		for(int i=0;i<positions2.length;i++) {
			disc.go(positions2[i]);
		}
		System.out.println("\nFCFS: "+disc.totalMovement);
		System.out.print("Queue of execution: \n");
        for(int p:positions2)System.out.print(p+ " ");
        
	
}

public static int findMin(Disc disc, ArrayList<Proces> input){
    int index = -1, minimum = Integer.MAX_VALUE;
    for (int i = 0; i < input.size(); i++) {
    	int temp=disc.posDiff(input.get(i).position);
    	boolean isGood=input.get(i).isAccesed;
        if (isGood==false && minimum > temp) {
             
            minimum = temp;
            index = i;
        }
    }
    return index;
}
    public static void SSTF(Disc disc, ArrayList<Proces> input) {
    	int[] queue=new int[input.size()];
        for (int i = 0; i < input.size(); i++) {
            int index = findMin(disc, input);
            input.get(index).acces();
            queue[i]=input.get(index).position;
            disc.go(input.get(index).position);
            }
        System.out.println("\nSSFT: "+disc.totalMovement);
        System.out.print("Queue of execution: \n");
        for(int p:queue)System.out.print(p+ " "); 
    }
    public static void EDF(Disc disc, ArrayList<Proces> input) {
    	int[] positionsTemp=new int[input.size()];
    	for(int i=0;i<positionsTemp.length;i++) {
    		positionsTemp[i]=input.get(i).dedline;
    	}
    	Arrays.sort(positionsTemp);
    	int[] pos=new int[input.size()];
    	for(int i=0;i<pos.length;i++) {
    		for (int j=0;j<input.size();j++) {
    			if(input.get(j).dedline==positionsTemp[i] && input.get(j).isAccesed==false) {
    				pos[i]=input.get(j).position;
    				input.get(j).acces();
    				break;
    			}
    		}
    	}
    	for(int p:pos) disc.go(p);
    	System.out.println("\nEDF: "+disc.totalMovement);
        System.out.print("Queue of execution: \n");
        for(int p:pos)System.out.print(p+ " "); 
        System.out.print("\nDedlines of execution: \n");
        for(int p:positionsTemp)System.out.print(p+ " "); 
    }
    public static boolean everyProcesAccesed(ArrayList<Proces> input) {
    	boolean is=true;
    	for(Proces p:input) {
    		if (p.isAccesed==false) { is=false; break;}
    	}
    	return is;
    }
    public static int indexOfMin(ArrayList<Proces> input) {
    	int min=Integer.MAX_VALUE;
    	int index=0;
    	for(int i=0;i<input.size();i++) {
    		if(input.get(i).isAccesed==false && input.get(i).dedline<min) {
    			min=input.get(i).dedline;
    			index=i;
    		}
    	}
    	return index;
    }
    public static void FDSCAN(Disc disc, ArrayList<Proces> input) {
    	int[] positionsTemp=new int[input.size()];
    	ArrayList<Proces> queue=new ArrayList<Proces>();
    	for(int i=0;i<positionsTemp.length;i++) {
    		positionsTemp[i]=input.get(i).position;
    	}
    	Arrays.sort(positionsTemp);
    	int[] pos=new int[input.size()];
    	while(everyProcesAccesed(input)==false) {
    		int index =indexOfMin(input);
    		Proces temp= input.get(index);
    		input.get(index).acces();
    		if(temp.position>disc.actualPosition) {
    			for(int i=0;i<positionsTemp.length;i++) {
    				if(positionsTemp[i]>disc.actualPosition && positionsTemp[i]<temp.position) {
    					for(Proces p:input) {
    						if(p.isAccesed==false && p.position==positionsTemp[i]) {
    							p.acces();
    							queue.add(p);
    						}
    					}
    				}
    			}
    		}else {
    			for(int i=positionsTemp.length-1;i>-1;i--) {
    				if(positionsTemp[i]<disc.actualPosition && positionsTemp[i]>temp.position) {
    					for(Proces p:input) {
    						if(p.isAccesed==false && p.position==positionsTemp[i]) {
    							p.acces();
    							queue.add(p);
    						}
    					}
    				}
    		}
    		}
    		queue.add(temp);
    	}
    	int[] pos2=new int[input.size()];
    	for(int i=0;i<pos2.length;i++) {
    		pos2[i]=queue.get(i).position;
    	}
    	for(int p:pos2) disc.go(p);
    	System.out.println("\nFD-SCAN: "+disc.totalMovement);
        System.out.print("Queue of execution: \n");
        for(int p:pos2) System.out.print(p+ " ");
    	
    }
 /*   public static void FDSCAN(Disc disc, ArrayList<Proces> input) {
    	int[] positionsTemp=new int[input.size()];
    	for(int i=0;i<positionsTemp.length;i++) {
    		positionsTemp[i]=input.get(i).dedline;
    	}
    	Arrays.sort(positionsTemp);
    	int[] pos=new int[input.size()];
    	for(int i=0;i<pos.length;i++) {
    		for (int j=0;j<input.size();j++) {
    			if(input.get(j).dedline==positionsTemp[i] && input.get(j).isAccesed==false) {
    				pos[i]=input.get(j).position;
    				input.get(j).acces();
    				break;
    			}
    		}
    	}
    	for(Proces p:input)p.reset();
    	boolean goRight=false;
    	int[] pos2=new int[input.size()];
    	for(int i=0;i<pos2.length;i++) {
    		for(int j=0;j<input.size();j++) {
    			if(input.get(j).position==pos[i] && input.get(j).isAccesed==false) {
    				pos2[i]=input.get(j).position;
    				input.get(j).acces();
    				break;
    			}
    		}
    		if(pos2[i]>disc.actualPosition) goRight=true;
    		else goRight=false;
    		
    		if(goRight==true) {
    			for(int k=0;k<pos.length;k++) {
    				if(pos[k]>disc.actualPosition && pos[k]<pos2[i]&&input.get(k).isAccesed==false) {
    					i++;
    					pos2[i]=pos[k];
    					input.get(k).acces();
    				}
    			}
    		}else {
    			for(int k=pos.length-1;k>-1;k--) {
    				if(pos[k]<disc.actualPosition && pos[k]>pos2[i]&& pos[k]<pos2[i]&&input.get(k).isAccesed==false) {
    					i++;
    					pos2[i]=pos[k];
    					input.get(k).acces();
    				}
    			}
    		}
    	}
    	for(int p:pos2) disc.go(p);
    	System.out.println("\nFD-SCAN: "+disc.totalMovement);
        System.out.print("Queue of execution: \n");
        for(int p:pos2)System.out.print(p+ " "); 

    }
 /*   public int edf(ArrayList<Integer> deadlines) {
        
        int earliest = Integer.MAX_VALUE,earliestIndex = Integer.MAX_VALUE;
       
        for (int i = 0; i < deadlines.size(); i ++) {
           
	 if (deadlines.get(i) < earliest) {
               
                 earliest = deadlines.get(i);
              
	         earliestIndex = i;
            }
        }
        return earliestIndex;
    }
    public void fdscan(ArrayList<Integer> processes, Disc disk, ArrayList<Integer> deadlines) {
        
    	int index = 0 , dist = Integer.MAX_VALUE;
        
            boolean ch = false;
            
          for (int i = 0; i < processes.size(); i++) {
               
                boolean r = disk.getHeadPos() < processes.get(clo) && processes.get(i) < processes.get(clo);
                boolean l = disk.getHeadPos() > processes.get(clo) && processes.get(i) > processes.get(clo);
                
    		if ( disk.posDiff ( processes.get(i) ) < dist && (r || l) ) {
                  
                    ch = true;
                  
    	        index = i;
                   
                    dist = disk.posDiff ( processes.get(i) );
                }
            }
            if (ch)  Sysmtem.out.println ( index ) ;
          
            else  edf(processes);
          
        }*/
	public static void main(String[] args) {
		Disc disc=new Disc(53, 200);
		ArrayList<Proces> input=new ArrayList<Proces>();
		input.add(new Proces(98, 40));
		input.add(new Proces(183, 60));
		input.add(new Proces(37, 20));
		input.add(new Proces(122, 10));
		input.add(new Proces(14, 5));
		input.add(new Proces(124, 14));
		input.add(new Proces(65, 20));
		input.add(new Proces(67, 300));
		input.add(new Proces(84, 26));
		input.add(new Proces(2, 45));
		SCAN(disc, input);
		disc.reset();
		CSCAN(disc, input);
		disc.reset();
		FCFS(disc, input);
		disc.reset();
		SSTF(disc, input);
		disc.reset();
		for(Proces p:input)p.reset();
		EDF(disc, input);
		disc.reset();
		for(Proces p:input)p.reset();
		FDSCAN(disc, input);
		Disc disc2=new Disc(146, 400);
		ArrayList<Proces> input2=new ArrayList<Proces>();
		input2.add(new Proces(12, 40));
		input2.add(new Proces(183, 50));
		input2.add(new Proces(340, 120));
		input2.add(new Proces(399, 86));
		input2.add(new Proces(245, 20));
		input2.add(new Proces(222, 21));
		input2.add(new Proces(134, 28));
		input2.add(new Proces(45, 280));
		input2.add(new Proces(86, 78));
		input2.add(new Proces(123, 123));
		input2.add(new Proces(48, 44));
		input2.add(new Proces(257, 67));
		input2.add(new Proces(30, 98));
		input2.add(new Proces(320, 46));
		input2.add(new Proces(150, 67));
		input2.add(new Proces(311, 148));
		input2.add(new Proces(212, 90));
		input2.add(new Proces(95, 330));
		input2.add(new Proces(275, 243));
		input2.add(new Proces(233, 352));
		System.out.print("\nQueue of deadlines: \n");
        for(Proces p:input2)System.out.print(p.dedline + " ");
		SCAN(disc2, input2);
		disc2.reset();
		CSCAN(disc2, input2);
		disc2.reset();
		FCFS(disc2, input2);
		disc2.reset();
		SSTF(disc2, input2);
		disc2.reset();
		for(Proces p:input2)p.reset();
		EDF(disc2, input2);
		disc2.reset();
		for(Proces p:input2)p.reset();
		FDSCAN(disc2, input2);
	}
}
