package pageReplacement;

import java.util.ArrayList;
import java.util.Scanner;

public class IDM {
	public int frameNumber;
	ArrayList<Integer> references=new ArrayList<Integer>();
	int[] pages;
	
	 public IDM(Scanner scan) {
		 System.out.print("How big will be frame: ");
		 frameNumber=scan.nextInt();
		 System.out.print("Write your references(any letter to stop): ");
		 while(scan.hasNextInt()) {
			 references.add(scan.nextInt());
		 }
		 pages=new int[references.size()];
		 for(int i=0;i<pages.length;i++) {
			 pages[i]=references.get(i);
		 }
	 }
}
	 
