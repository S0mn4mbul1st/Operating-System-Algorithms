package pageReplacement;


import java.util.Scanner;

public class VM {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		IDM test=new IDM(scan);
		SM.FIFO(test.pages, test.pages.length, test.frameNumber);
		SM.OPT(test.references, test.frameNumber);
		SM.LRU(test.pages, test.pages.length, test.frameNumber);
		SM.aLRU(test.references, test.frameNumber);
		SM.Rand(test.pages, test.pages.length, test.frameNumber);	
	}
}
