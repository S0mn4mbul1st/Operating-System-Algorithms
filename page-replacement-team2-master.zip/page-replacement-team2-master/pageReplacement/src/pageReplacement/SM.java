package pageReplacement;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class SM {
	public static void LRU(int pages[], int n, int frameNumber) {
		System.out.println("LRU:");
	        ArrayList<Integer> s=new ArrayList<>(frameNumber); 
	        ArrayList<Integer> page=new ArrayList<>(frameNumber);
	        int count=0; 
	        int page_faults=0; 
	        for(int i:pages) 
	        { 

	        	if(!s.contains(i)) 
	            { 
	        		
	            if(s.size()==frameNumber) 
	            { 
	            	int index=page.indexOf(s.get(0));
	                s.remove(0); 
	                page.remove(index);
	                s.add(frameNumber-1,i);
	                page.add(index, i);
	                System.out.println("Ref: "+i);
	                System.out.print("[ ");
	                for(int j=0;j<frameNumber;j++) {
	                	if(page.size()<=j) {
	                		System.out.print("- ");
	                	}else {
	                	System.out.print(page.get(j)+" ");
	                	}
	                }
	                System.out.println("]");
	                
	            } 
	            else{
	                s.add(count,i);
	                page.add(count, i);
	                System.out.println("Ref: "+i);
	                System.out.print("[ ");
	                for(int j=0;j<frameNumber;j++) {
	                	if(page.size()<=j) {
	                		System.out.print("- ");
	                	}else {
	                	System.out.print(page.get(j)+" ");
	                	}
	                }
	                System.out.println("]");
	            }
	            
	                page_faults++; 
	                ++count; 
	          
	            } 
	            else
	            { 
	                s.remove((Object)i); 
	                s.add(s.size(),i); 
	                System.out.println("Ref: "+i);
	                System.out.print("[ ");
	                for(int j=0;j<frameNumber;j++) {
	                	if(page.size()<=j) {
	                		System.out.print("- ");
	                	}else {
	                	System.out.print(page.get(j)+" ");
	                	}
	                }
	                System.out.println("]");
	            } 
	          
	        } 
	        System.out.println("Number of page faults: " + page_faults +"\n");
	    } 
	
	public static void FIFO(int pages[], int n, int frameNumber) 
    { 
        HashSet<Integer> s = new HashSet<>(frameNumber); 
        ArrayList<Integer> page=new ArrayList<>(frameNumber); 
        Queue<Integer> indexes = new LinkedList<>() ; 
        System.out.println("FIFO:");
        int page_faults = 0; 
        int count=0;
        for (int i=0; i<n; i++) 
        { 
        
            if (s.size() < frameNumber) 
            { 
                if (!s.contains(pages[i])) 
                { 
                    s.add(pages[i]);
                    page.add(pages[i]);
                    page_faults++; 
     
                    indexes.add(pages[i]);
                    System.out.println("Ref: "+pages[i]);
                    System.out.print("[ ");
                    for(int j=0;j<frameNumber;j++) {
                    	if(page.size()<=j) {
                    		System.out.print("- ");
                    	}else {
                    	System.out.print(page.get(j)+" ");
                    	}
                    }
                    System.out.println("]");
                    
                } else {
                	System.out.println("Ref: "+pages[i]);
                    System.out.print("[ ");
                    for(int j=0;j<frameNumber;j++) {
                    	if(page.size()<=j) {
                    		System.out.print("- ");
                    	}else {
                    	System.out.print(page.get(j)+" ");
                    	}
                    }
                    System.out.println("]");
                }
            } 
            else
            { 
                if (!s.contains(pages[i])) 
                { 
                    
                    int val = indexes.peek(); 
                    
                    indexes.poll(); 
 
                    s.remove(val); 
                    s.add(pages[i]); 
                    page.remove(count);
                    page.add(count, pages[i]);
                    indexes.add(pages[i]); 
       
                    page_faults++; 
                    System.out.println("Ref: "+pages[i]);
                    System.out.print("[ ");
                    for(int j=0;j<frameNumber;j++) {
                    	if(page.size()<=j) {
                    		System.out.print("- ");
                    	}else {
                    	System.out.print(page.get(j)+" ");
                    	}
                    }
                    System.out.println("]");
                    
                    count++;
                    if(count==page.size()) {
                    	count=0;
                    }
                } else {
                	System.out.println("Ref: "+pages[i]);
                    System.out.print("[ ");
                    for(int j=0;j<frameNumber;j++) {
                    	if(page.size()<=j) {
                    		System.out.print("- ");
                    	}else {
                    	System.out.print(page.get(j)+" ");
                    	}
                    }
                    System.out.println("]");
                }
            } 
        } 
       
        System.out.println("Number of page faults: " + page_faults +"\n");
    } 
	private static int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
	public static void Rand(int pages[], int n, int frameNumber) {
		 System.out.println("Rand:");
        ArrayList<Integer> s=new ArrayList<>(frameNumber); 
        ArrayList<Integer> page=new ArrayList<>(frameNumber); 
        int count=0; 
        int page_faults=0; 
        for(int i:pages) 
        { 

        	if(!s.contains(i)) 
            { 
        		
            if(s.size()==frameNumber) 
            { 
            	int random= getRandomNumberInRange(0, frameNumber-1);
                s.remove(random); 
                page.remove(random);
                s.add(random,i); 
                page.add(random, i);
                System.out.println("Ref: "+i);
                System.out.print("[ ");
                for(int j=0;j<frameNumber;j++) {
                	if(page.size()<=j) {
                		System.out.print("- ");
                	}else {
                	System.out.print(page.get(j)+" ");
                	}
                }
                System.out.println("]");
            } 
            else {
                s.add(count,i);
                page.add(count, i);
                System.out.println("Ref: "+i);
                System.out.print("[ ");
                for(int j=0;j<frameNumber;j++) {
                	if(page.size()<=j) {
                		System.out.print("- ");
                	}else {
                	System.out.print(page.get(j)+" ");
                	}
                }
                System.out.println("]");
            }
            
        	page_faults++; 
            ++count; 
            }
            else
            {  
                System.out.println("Ref: "+i);
                System.out.print("[ ");
                for(int j=0;j<frameNumber;j++) {
                	if(page.size()<=j) {
                		System.out.print("- ");
                	}else {
                	System.out.print(page.get(j)+" ");
                	}
                }
                System.out.println("]");
            } 
          
        } 
        System.out.println("Number of page faults: " + page_faults +"\n");
    }
	
	public static void OPT(ArrayList<Integer> AppealList, int frameNumber) {
		System.out.println("OPT:");
        int err = 0;
        ArrayList<Integer> page=new ArrayList<>(frameNumber);
        ArrayList<Integer> FrameList = new ArrayList<Integer>();
        int temp=0;
       for (int i = 0; FrameList.size() < frameNumber; i++)
	   
           if (!FrameList.contains(AppealList.get(i))) {
        	   FrameList.add(AppealList.get(i));
        	   page.add(AppealList.get(i));
        	   err++;
        	   temp++;
        	   System.out.println("Ref: "+AppealList.get(i));
        	   System.out.print("[ ");
           		for(int j=0;j<frameNumber;j++) {
           			if(page.size()<=j) {
           				System.out.print("- ");
           			}else {
           				System.out.print(page.get(j)+" ");
           			}
           		}
           		System.out.println("]");
           		}else {
           			System.out.println("Ref: "+AppealList.get(i));
             	   System.out.print("[ ");
                		for(int j=0;j<frameNumber;j++) {
                			if(page.size()<=j) {
                				System.out.print("- ");
                			}else {
                				System.out.print(page.get(j)+" ");
                			}
                		}
                		System.out.println("]");
                		temp++;
           		}
		

	ArrayList<Integer> AppC = new ArrayList<Integer>(AppealList);
	for(int i=0; i<temp; i++) {
		AppC.remove(0);
	}
	while (AppC.size() > 0) {
		
           if (!FrameList.contains(AppC.get(0))) {
		
               err++;
		
               boolean checker = false;
               int index=0;
               for (int j = 0; j < FrameList.size() && !checker; j++) {
		
                   if (!AppC.contains(FrameList.get(j))) {
                	   index = page.indexOf(FrameList.get(j));
                       FrameList.remove(j);
                       page.remove(index);
		
                       checker = true;
		  
                   }
		}
	
               if (!checker) {
		  
                   ArrayList<Integer> FrameC = new ArrayList<Integer>(FrameList);
		
                   Integer endPoint = null;
		 
                   for (int j = 0; j < AppC.size() && FrameC.size() > 0; j++) {
		
                       if (FrameC.contains(AppC.get(j))) {
		
                           endPoint = AppC.get(j);
		
                           FrameC.remove(AppC.get(j));
			}
		    }

                   FrameList.remove(endPoint);
                   index=page.indexOf(endPoint);
                   page.remove(index);
		}
		
               FrameList.add(AppC.get(0));
               page.add(index, AppC.get(0));

	    }
	 
           
           System.out.println("Ref: "+AppC.get(0));
    	   System.out.print("[ ");
       		for(int j=0;j<frameNumber;j++) {
       			if(page.size()<=j) {
       				System.out.print("- ");
       			}else {
       				System.out.print(page.get(j)+" ");
       			}
       		}
       		System.out.println("]");
       		AppC.remove(0);
       		
       }
	System.out.println("Number of page faults: " + err +"\n");
   }

public static int FrameFiller(ArrayList<Integer> page, ArrayList<Integer> ListApp, ArrayList<Page> FrameList, int memory) {
	int temp=0;
                    for (int i = 0; FrameList.size() < memory; i++) {
                    	temp++;
                        boolean ch = false;
	  
                        for (int j = 0; j < FrameList.size() && !ch; j++)
	
                            if (FrameList.get(j).val == ListApp.get(i))
	
                                ch = true;
                        
	    if (!ch) {
	    	FrameList.add(new Page(ListApp.get(i)));
	    	page.add(ListApp.get(i));
	    }
	    System.out.println("Ref: "+ListApp.get(i));
 	   System.out.print("[ ");
    		for(int j=0;j<memory;j++) {
    			if(page.size()<=j) {
    				System.out.print("- ");
    			}else {
    				System.out.print(page.get(j)+" ");
    			}
    		}
    		System.out.println("]");
	    }
		
	    return temp;
	}

public static void aLRU(ArrayList<Integer> ListApp, int frameNumber) {
System.out.println("aLRU:");
int err = 0;
int temp=0;
int index=-1;
ArrayList<Integer> page=new ArrayList<>(frameNumber);
ArrayList<Page> ListFrames = new ArrayList<Page>();
	
ArrayList<Integer> AppCopy = new ArrayList<Integer>(ListApp);

temp=FrameFiller(page, ListApp, ListFrames, frameNumber);
err=err+frameNumber;
for(int i=0; i<temp; i++) {
	AppCopy.remove(0);
}
	
	while (AppCopy.size() > 0) {
	
boolean checker = false;
	
for (int i = 0; i < ListFrames.size(); i++)
	
if (ListFrames.get(i).val == AppCopy.get(0)) {
	
int sec = AppCopy.get(0);
	
ListFrames.remove(i);
	
ListFrames.add(new Page(sec));
	
checker = true;
	
}
	    if (checker == false) {	
err++;
		
boolean freee = false , freeePre = false , pointer = false;

		for (int k = 0; k < ListFrames.size(); k++)
		
if (ListFrames.get(k).ind == true && pointer == false) {
	index=page.indexOf(ListFrames.get(k).val);
ListFrames.remove(k);
page.remove(index);	
freeePre = true;
			
pointer = true;
		
}
		
if (freeePre == false) {
		
for (int l = 0; l < ListFrames.size(); l++)	ListFrames.get(l).ind = true;
			 
for (int k = 0; k < ListFrames.size(); k++)
			
if (ListFrames.get(k).ind == true && freee == false) {
	index=page.indexOf(ListFrames.get(k).val);   
ListFrames.remove(k);
page.remove(index);
			   
freee = true;
			}
		}

		ListFrames.add(new Page(AppCopy.get(0)));
		page.add(index, AppCopy.get(0));
	    }
	    System.out.println("Ref: "+AppCopy.get(0));
 	   System.out.print("[ ");
    		for(int j=0;j<frameNumber;j++) {
    			if(page.size()<=j) {
    				System.out.print("- ");
    			}else {
    				System.out.print(page.get(j)+" ");
    			}
    		}
    		System.out.println("]");
	    AppCopy.remove(0);
	}

	System.out.println("Number of page faults: " + err +"\n");
   }
}
class Page {
    
    int val;
    boolean ind;

    Page(int val) {
	this.val = val;
	ind = false;
    }

    public String toString() {
	return val + " " + ind;
    }
}
