import java.util.ArrayList;

public class Test {
    void proceed(int amountOfProcesses, int amountOfFrames, int amountOfPages, int range, int controlRatePer10Pages, int localityDelta) {
        ProcessesGenerator processesGenerator = new ProcessesGenerator();
        ArrayList<Process> processes = processesGenerator.generate(amountOfProcesses,amountOfPages,range);

        Proportional proportional = new Proportional();
        Equal equal = new Equal();
        PFF pff = new PFF();
        WorkingSet workingSet= new WorkingSet();
        String proceses="Number of pages in all processes: \n";
        for(Process p: processes) {
        	proceses+=p.toString()+" ";
        }
        System.out.println(proceses);	
        System.out.println("Proportional: " + proportional.proportional(processes, amountOfFrames));       
        System.out.println("Equal: " + equal.equal(processes, amountOfFrames));
        System.out.println("Page Foult Frequency with rate "+controlRatePer10Pages+":" + pff.pff(processes, amountOfFrames, controlRatePer10Pages));
        System.out.println("Working set with delta "+localityDelta+":" + workingSet.workingSet(processes, amountOfFrames, localityDelta));
    }
}
