public class Main {
    public static void main(String[] args) {
        Test test = new Test();
        test.proceed(30, 400, 90, 50, 8, 30);
    }
}
