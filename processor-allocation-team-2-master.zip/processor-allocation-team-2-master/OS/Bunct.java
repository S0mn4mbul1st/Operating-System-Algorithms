
import java.util.ArrayList;
import java.util.Random;

class Bunct {
  
    ArrayList<Processor> processors;
   
    int contr;

    public Bunct(int n, int threshold) {
      
        this.processors = new ArrayList<>();
     
        for (int i = 0; i < n; i++)  processors.add(new Processor(i, threshold));
    }


   
      public int newHolder() {
        int total = 0;
        for (Processor processor : processors) {
            total += processor.remover();
        }
        return total;
    }

	public Processor selectRandom() {
		Random random = new Random();
        return processors.get(random.nextInt(processors.size()));
	}
     
}
