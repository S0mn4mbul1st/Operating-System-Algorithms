
class Process {
    public int load , nTicker , waiting;

    public Process(int load, int nTicker, int waiting) {
      
        this.load = load;
       
        this.nTicker = nTicker;
      
        this.waiting = waiting;
    }
    
}
