import java.util.ArrayList;
import java.util.Random;


class Simulator{
    
    ArrayList<Processor> procs ;
     ArrayList<Process>proc;

    Bunct bunch;
    
    int nTicker = 0 ,request = 0 ,migrations = 0 ,size;

    Random random = new Random();

    public Simulator( int size, ArrayList<Process> proc) {
               
        this.size = size;
        
        this.proc = proc;
        
    }

    private void random() {
       
        int handled = 0;
      
        Processor signed = bunch.selectRandom();
    
       while ( handled != proc.size() ) {
       
            int tot = 0;
          
            bunch.newHolder();
               
            for (Processor proc : procs)  tot += proc.remover();
           
            Process process = proc.get ( handled );
          
            if (process.nTicker > nTicker) {
          
                 nTicker++;
           
                 for (Processor proc : procs)  proc.nTicker ++;
                
                 continue;
            }      
            signed.insert( process );
        
            request ++;
         
            if ( signed.curLoad() + process.load > signed.threshold ) {
          
                for ( int i = 0 ; i < size; i ++ ) {
          
                    Processor candi = procs.get ( random.nextInt (proc.size() ) );
            
                    request ++;
            
                    if ( candi.curLoad() + process.load < candi.threshold ) {
            
                        signed.transfer ( candi );
             
                        migrations ++;
             
                        break;
                    }
                }
            }
            handled ++;
        }
        boolean ch = true ;
        
         for (Processor processor : procs)  if (processor.curLoad() > 0)  ch = false;

         while ( ! ch ) {

             for (Processor proc : procs)  proc.nTicker ++;
        
             bunch.newHolder();
        
             nTicker ++;
        }
    }
    
    public String toString() {
        return gcurLoad();
    }
    
    public String gcurLoad() {
        int counter = 0;
        for (Process process : proc) {
            counter += process.load;
        }
        return counter + " ";
    }


}
