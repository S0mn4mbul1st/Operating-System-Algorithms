package main;

import java.util.ArrayList;
import java.util.Scanner;


public class Test {
    
     public void Start() {
        
         Scanner scan = new Scanner ( System.in ) ; 
         
         int p, r , z , N ;  
       
         System.out.println(" p : ") ; p = scan.nextInt() ; 
           System.out.println("\n r : ") ; r = scan.nextInt() ; 
            System.out.println("\n z : ") ; z = scan.nextInt() ;  
             System.out.println("\n N : ") ; N = scan.nextInt() ;
             
              ArrayList<Process> processes = new ArrayList<Process> ();
              
              for ( int i = 0; i < z ; i ++  ){
                  
                  System.out.println("\n" + i + ". Process : \n") ;  
                  
                System.out.println("\n Load : ") ;  int load = scan.nextInt() ;
                System.out.println("\n NewTicker : ") ;  int nTicker = scan.nextInt();
                System.out.println("\n Duration Time : ") ;  int waiting = scan.nextInt();
                  
                  Process num =new Process ( load, nTicker, waiting ) ;
                  
                  processes.add(num);
              }
                  
         operation Input =new operation( r , z , p , N , processes) ;  
         
         Input.simulate();     
    }
    
}
