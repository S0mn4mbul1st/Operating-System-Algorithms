package main;

public enum Algorithms {
  
    First; 
        
}

