package main;

import java.util.ArrayList;
import java.util.Iterator;

public class Processor {
  
      int threshold , nTicker;
    
      ArrayList<Process> helder = new ArrayList<>() ;

    public Processor( int threshold) {

        this.threshold = threshold;
      
        this.nTicker = 0;
    }

    public int curLoad() {
      
        int ans = 0;
       
        for (Process proc : helder)   ans += proc.load;

        return ans;
    }


    public int remover() {
        
        int ans = 0;
        
        Iterator<Process> fuc = helder.iterator();
   
        while ( fuc.hasNext() ) {
      
            Process proc = fuc.next();
       
            if (proc.nTicker + proc.waiting <= this.nTicker) {
      
                ans ++;
           
                fuc.remove();
            }
        }
        return ans;
    }

    public void insert(Process proc) {  this.helder.add(proc); }
      
    public void transfer(Processor var) {
      
        int pos = helder.size();
        
        Process proc = helder.get ( pos -- ) ;
      
        helder.remove(pos);
       
        var.insert(proc);
    }

   
   @Override
    public String toString() {
        return gcurLoad() + " ";
    }
    
    public int gcurLoad() {
       int ans = 0;
      
       for (Process process : helder ) ans += process.load;

        return ans;
    }
    
}
