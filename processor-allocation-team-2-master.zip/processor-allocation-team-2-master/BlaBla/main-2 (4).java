package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;


class operation{
    
    ArrayList<Process> processes;

    Bunct bunch;
    
    int r , z , p , N ,  nTicker = 0 ,request = 0 ,migrations = 0; 

     HashMap<Algorithms, ArrayList<Double>> mean = new HashMap<>();
     HashMap<Algorithms, ArrayList<Double>> median = new HashMap<>();
     HashMap<Algorithms, ArrayList<Integer>> load = new HashMap<>();
     HashMap<Algorithms, ArrayList<Integer>> migrated = new HashMap<>();
    
    Random random = new Random();

      public operation(int p, int r, int z, int N, ArrayList<Process> processes) {
     
          this.bunch = new Bunch(N, p);
       
          this.r = r;
        
          this.z = z;
        
          this.N = N;
        
          this.p = p;
        
          this.processes = processes;
        
          for (Algorithms algorithm : Algorithms.values()) {
          
              mean.put(algorithm, new ArrayList<>());
            
              median.put(algorithm, new ArrayList<>());
            
              load.put(algorithm, new ArrayList<>());
            
              migrated.put(algorithm, new ArrayList<>());
        }
    }

    private void random() {
       
        int handled = 0;
      
        Processor signed = bunch.processors.get( random.nextInt( bunch.processors.size() ) );
    
        while ( handled != processes.size() ) {
       
           bunch.newHolder();
           
           int tot = 0;
          
            bunch.newHolder();
               
            for (Processor proc : bunch.processors)  tot += proc.remover();
           
            Process process = processes.get ( handled );
          
            if (process.nTicker > nTicker) {
          
                 nTicker++;
           
                 for (Processor proc : bunch.processors)  proc.nTicker ++;
                
                 continue;
            }      
            signed.insert( process );
        
            request ++;
         
            if ( signed.curLoad() + process.load > signed.threshold ) {
          
                for ( int i = 0 ; i < z; i ++ ) {
          
                    Processor candi =  bunch.processors.get( random.nextInt(bunch.processors.size()) ) ;
            
                    request ++;
            
                    if ( candi.curLoad() + process.load < candi.threshold ) {
            
                        signed.transfer ( candi );
             
                        migrations ++;
             
                        break;
                    }
                }
            }
            handled ++;
        }
        boolean ch = true ;
        
         for (Processor processor : bunch.processors)  if (processor.curLoad() > 0)  ch = false;

         while ( ! ch ) {

             for (Processor proc : bunch.processors)  proc.nTicker ++;
        
             bunch.newHolder();
        
             nTicker ++;
        }
    }
    public String toString() { return gcurLoad(); }
    
    public String gcurLoad() {
      
        int counter = 0;
       
        for (Process process : processes)  counter += process.load;
               
        return counter + " ";
    }
    
    private void zero() {
       
        bunch = new Bunch(p);
        
        request = 0;
        
        migrations = 0;
        
        nTicker = 0;
    }
    
    
     public void simulate() {
        random();
     
        zero();
    }

}
