public class Main {
    
    public static void main(String[] args) {
        
        Test Value = new Test(); 
        
        Value.Start();
        
    }
}
