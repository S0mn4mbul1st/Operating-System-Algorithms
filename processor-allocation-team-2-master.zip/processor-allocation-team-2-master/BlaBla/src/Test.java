
import java.util.ArrayList;
import java.util.Scanner;


public class Test {
    
     public void Start() {
        
         Scanner scan = new Scanner ( System.in ) ; 
         
         int p, r , z , N ;  
       
         System.out.println("p : ") ; p = scan.nextInt() ; 
           System.out.println("r : ") ; r = scan.nextInt() ; 
            System.out.println("z : ") ; z = scan.nextInt() ;  
             System.out.println("N : ") ; N = scan.nextInt() ;
             
              ArrayList<Process> processes = new ArrayList<Process> ();
              
              for ( int i = 0; i < z ; i ++  ){
                  
                  System.out.println("\n" + (i+1) + ". Process : \n") ;  
                  
                System.out.println("Load : ") ;  int load = scan.nextInt() ;
                System.out.println("NewTicker : ") ;  int nTicker = scan.nextInt();
                System.out.println("Duration Time : ") ;  int waiting = scan.nextInt();
                  
                  Process num =new Process ( load, nTicker, waiting ) ;
                  
                  processes.add(num);
              }
                  
         operation Input =new operation( r , z , p , N , processes) ;  
         
         Input.simulate();     
    }
    
}
