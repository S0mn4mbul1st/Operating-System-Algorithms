
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

class Bunct {
  
    ArrayList<Processor> processors;
   
    int counter;
     
      Random random = new Random();
    
    public void formatCounter() { counter = 0;}
    
    public Bunct(int n, int threshold) {
      
        this.processors = new ArrayList<>();
     
        for (int i = 0; i < n; i++)  processors.add(new Processor( threshold ) );
    }

      public int newHolder() {
    
        int total = 0;
      
        for (Processor processor : processors)    total += processor.remover();
 
        return total;
    }
      
      public double getMeanLoad() {
    
          double mean = 0.0;
        
          for (Processor processor : processors)   mean += processor.gcurLoad();

        mean /= processors.size();

        return mean;
    }
      
      public Processor drawLowerThan(int threshold) {
       
          ArrayList<Processor> candidates = new ArrayList<>();
        
          for (Processor processor : processors) {
          
              if (processor.gcurLoad() < threshold)  candidates.add(processor);
        }
        if (candidates.size() == 0)   return drawLowerThan(threshold + 1);
          
        if (candidates.size() == 1) {
            counter++;
          
            return candidates.get(0);
        }

        counter++;
      
        return candidates.get(random.nextInt(candidates.size()));
    }
      
      
      public double getMedianLoad() {
    
          ArrayList<Integer> loads = new ArrayList<>();
        
          for (Processor processor : processors)  loads.add(processor.gcurLoad());
           
          Collections.sort(loads);
        
          if (loads.size() % 2 == 1)  return (double) loads.get(loads.size() / 2);
           
          else   return (double) (loads.get((loads.size() / 2) - 1) + loads.get(loads.size() / 2)) / 2.0;
   
    }
}
