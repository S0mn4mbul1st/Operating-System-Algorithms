
public enum Algorithms {
  
    First, Second; 
        
}

