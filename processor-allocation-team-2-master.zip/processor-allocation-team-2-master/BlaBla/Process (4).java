package main;

class Process implements Comparable{
    public final int load , nTicker , waiting;

    public Process(int load, int nTicker, int waiting) {
      
        this.load = load;
       
        this.nTicker = nTicker;
      
        this.waiting = waiting;
    }

    @Override
    public int compareTo(Object other) {
      
        Process o = (Process) other;
     
        return this.nTicker - o.nTicker;
    }

}
