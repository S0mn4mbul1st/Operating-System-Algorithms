import java.util.ArrayList;
import java.util.Collections;

public class Processor {
ArrayList<Process> que=new ArrayList<Process>();
ArrayList<Process> all=new ArrayList<Process>();
int thereshold;
int index;
public Processor( int i) {
	index=i;
}
public int getLoad(){
	int load=0;
	if(que.size()==0) return 0;
	for(Process p: que) {
		load+=p.weight;
	}
	return load;
}
public int getMean() {
	if(all.size()==0) return 0;
	Collections.sort(all);
	int time=all.get(all.size()-1).startTime+all.get(all.size()-1).duration;
	int sum=0;
	for(Process p: all) {
		sum+=(p.duration*p.weight);
	}
	return sum;
}
}
