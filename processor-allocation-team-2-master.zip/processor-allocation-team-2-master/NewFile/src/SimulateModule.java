import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class SimulateModule {
ArrayList<Event> events=new ArrayList<Event>();
ArrayList<Process> proc=new ArrayList<Process>();
ArrayList<Processor> processors;
int r, z, num, p;
Random rand= new Random();

public SimulateModule(ArrayList<Processor> processors, int r, int z, int number, int p ) {
	this.processors=processors;
	this.r=r;
	this.z=z;
	this.p=p;
	num=number;
	simulate();
}

public void simulate() {
	processGenerator();
	fillEvents();
	first();
	reset();
	fillEvents();
	second();
	reset();
	fillEvents();
	third();
	
}
public void processGenerator() {
	for(int i=0; i<num;i++) {
		int start=rand.nextInt((2*i) +1);
		int duration=rand.nextInt(num*3);
		int weight=rand.nextInt(21);
		Process e= new Process(start, duration+10, weight+3);
		proc.add(e);
	}
}
public void fillEvents() {
	for(Process e: proc) {
		events.add(new Event(TypeOfEvent.Start, e, e.startTime ));
	}
	Collections.sort(events);
}
public void reset() {
	events.clear();
	for(Processor p : processors) {
		p.que.clear();
		p.all.clear();
	}
}
public void first() {
	int request=0;
	int migrations=0;
	int time=0;
	while(events.size()>0) {
		Collections.sort(events);
		Event e=events.get(0);
		time=e.time;
		events.remove(0);
		if(e.type==TypeOfEvent.Start) {
		int num=rand.nextInt(processors.size());
		Processor starting=processors.get(num);
		request++;
		boolean ch=false;
		for(int i=0; i<z;i++) {
			num=rand.nextInt(processors.size());
			request++;
			Processor requested=processors.get(num);
			if(requested.getLoad()<p) {
				requested.que.add(e.proc);
				requested.all.add(e.proc);
				events.add(new Event(TypeOfEvent.End, requested, e.proc, e.proc.startTime+e.proc.duration));
				migrations++;
				ch = true;
				break;
			}
		}
		if(ch==false) {
			if(starting.getLoad()<101) {
			starting.que.add(e.proc);
			starting.all.add(e.proc);
			events.add(new Event(TypeOfEvent.End, starting, e.proc, e.proc.startTime+e.proc.duration));
		}else {
			e.time+=10;
			e.proc.duration+=10;
			e.proc.startTime+=10;
			events.add(e);
		}
			}
		}else {
			e.p.que.remove(e.proc);
		}
	}
	String ret="First Algorithm: \nMigrations: "+migrations+"\nRequests: "+request+"\nMean Values: ";
	for(Processor p: processors) {
		ret+="\nProcessor "+(p.index+1)+": "+p.getMean()/time;
	}
	System.out.print(ret+"\n");
}

public void second() {
	int request=0;
	int migrations=0;
	int time=0;
	while(events.size()>0) {
		Collections.sort(events);
		Event e=events.get(0);
		time=e.time;
		events.remove(0);
		if(e.type==TypeOfEvent.Start) {
		int num=rand.nextInt(processors.size());
		Processor starting=processors.get(num);
		request++;
	
		if(starting.getLoad()<p) {
			starting.que.add(e.proc);
			starting.all.add(e.proc);
			events.add(new Event(TypeOfEvent.End, starting, e.proc, e.proc.startTime+e.proc.duration));
		}else {
				int ch=0;
				boolean checker=false;
				ArrayList<Processor> cloned=new ArrayList<Processor>(processors);		
				while(cloned.size()>0) {
			num=rand.nextInt(processors.size());
			request++;
			Processor requested=processors.get(num);
			cloned.remove(requested);
			if(requested.getLoad()<p) {
				requested.que.add(e.proc);
				requested.all.add(e.proc);
				events.add(new Event(TypeOfEvent.End, requested, e.proc, e.proc.startTime+e.proc.duration));
				migrations++;
				checker=true;
				break;
			}
			ch++;
		}
		if(checker==false) {
			e.time+=10;
			e.proc.duration+=10;
			e.proc.startTime+=10;
			events.add(e);
		}
		}
		}else {
			e.p.que.remove(e.proc);
		}
	}
	String ret="Second Algorithm: \nMigrations: "+migrations+"\nRequests: "+request+"\nMean Values: ";
	for(Processor p: processors) {
		ret+="\nProcessor "+(p.index+1)+": "+p.getMean()/time;
	}
	System.out.print(ret+"\n");
}
public void  third() {
	int request=0;
	int migrations=0;
	int time=0;
	while(events.size()>0) {
		Collections.sort(events);
		Event e=events.get(0);
		time=e.time;
		events.remove(0);
		if(e.type==TypeOfEvent.Start) {
		int num=rand.nextInt(processors.size());
		Processor starting=processors.get(num);
		request++;
	
		if(starting.getLoad()<p) {
			starting.que.add(e.proc);
			starting.all.add(e.proc);
			events.add(new Event(TypeOfEvent.End, starting, e.proc, e.proc.startTime+e.proc.duration));
		}else {
				int ch=0;
				boolean checker=false;
				ArrayList<Processor> cloned=new ArrayList<Processor>(processors);		
				while(cloned.size()>0) {
			num=rand.nextInt(processors.size());
			request++;
			Processor requested=processors.get(num);
			cloned.remove(requested);
			if(requested.getLoad()<p) {
				requested.que.add(e.proc);
				requested.all.add(e.proc);
				events.add(new Event(TypeOfEvent.End, requested, e.proc, e.proc.startTime+e.proc.duration));
				migrations++;
				checker=true;
				break;
			}
			ch++;
		}
		if(checker==false) {
			e.time+=10;
			e.proc.duration+=10;
			e.proc.startTime+=10;
			events.add(e);
		}
		}
		}else {
			e.p.que.remove(e.proc);
			if(e.p.getLoad()<r) {
				int ch=0;
				while(ch<processors.size()*2) {
				
				num=rand.nextInt(processors.size());
				request++;
				Processor requested=processors.get(num);
				if(requested.getLoad()>p) {
					Process p=requested.que.get(requested.que.size()-1);
					requested.que.remove(p);
					requested.all.remove(p);
					e.p.que.add(p);
					e.p.all.add(p);
					for(Event ev: events) {
						if(ev.proc==p) {
							events.remove(ev);
							break;
						}
					}
					events.add(new Event(TypeOfEvent.End, requested, e.proc, e.proc.startTime+e.proc.duration));
					migrations++;
				}
				ch++;
				}
			
				
			}
		}
	}
	String ret="Third Algorithm: \nMigrations: "+migrations+"\nRequests: "+request+"\nMean Values: ";
	for(Processor p: processors) {
		ret+="\nProcessor "+(p.index+1)+": "+p.getMean()/time;
	}
	System.out.print(ret+"\n");
}

}
