import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	
	public static void main(String args[]) {
/*		Scanner scan=new Scanner(System.in);
		System.out.print("Write threshold of processors: ");
		int p=scan.nextInt();
		System.out.print("Write number of processors: ");
		int N=scan.nextInt();
		ArrayList<Processor> procesors=new ArrayList<Processor>();
		for(int i=0; i<N;i++) {
			procesors.add(new Processor(i));
		}
		System.out.print("Write minimal threshold of processors(r): ");
		int r=scan.nextInt();
		System.out.print("Write z for first algorithm: ");
		int z=scan.nextInt();
		System.out.print("Write number of processes: ");
		int number=scan.nextInt();
		SimulateModule  test=new SimulateModule(procesors, z, r, number, p);*/
		ArrayList<Processor> procesors=new ArrayList<Processor>();
		for(int i=0; i<30;i++) {
			procesors.add(new Processor(i));
		}
		SimulateModule  test=new SimulateModule(procesors, 10, 20, 1000, 50);
	}
}
