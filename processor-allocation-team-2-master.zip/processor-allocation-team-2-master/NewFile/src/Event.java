
public class Event implements Comparable<Event>{
	TypeOfEvent type;
	Processor p;
	Process proc;
	int time;
	
	
	public Event(TypeOfEvent types, Processor pr, Process pro, int timee) {
		type=types;
		p=pr;
		proc=pro;
		time= timee;
		
	}
	public Event(TypeOfEvent types, Process pro, int timee) {
		type=types;
		proc=pro;
		time= timee;
		
	}


	@Override
	public int compareTo(Event o) {
		
		return time - o.time;
	}
}
