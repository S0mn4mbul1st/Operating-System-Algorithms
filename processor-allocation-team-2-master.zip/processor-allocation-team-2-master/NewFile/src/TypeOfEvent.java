
public enum TypeOfEvent {
	Start,End;
}
