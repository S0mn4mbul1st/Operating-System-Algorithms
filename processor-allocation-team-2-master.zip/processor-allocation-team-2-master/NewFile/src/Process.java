
public class Process implements Comparable<Process>{
	int startTime;
	int duration;
	int weight;
	public Process(int st, int du, int we) {
		startTime=st;
		duration=du;
		weight=we;
	}
	@Override
	public int compareTo(Process o) {
		return(startTime+duration)-(o.startTime+o.duration);
	}
}
